"""
Calculator routes blueprint
Handles case saving and retrieval
"""
from datetime import datetime, timedelta, time

from flask import Blueprint, request, jsonify
import json as json_lib
from sqlalchemy import func
from app import db
from app.models.case import Case
from app.models.oxygen_calculation import OxygenCalculation
from app.utils.decorators import require_token

# Create blueprint for calculator routes
calculator_bp = Blueprint('calculator', __name__)


@calculator_bp.route('/cases', methods=['POST'])
@require_token
def save_case(current_user):
    """
    Save a patient case to database
    
    Requires JWT authentication. Case is automatically associated with logged-in user.
    
    Request body:
        {
            "patient_name": "John Doe",
            "patient_id": "P12345",
            "date": "2026-04-22",
            "surgery_type": "General Anesthesia",
            "anesthetic_agent": "Sevoflurane",
            "molecular_mass": "200.05",
            "vapor_constant": "184",
            "density": "1.52"
        }
    
    Returns:
        201: Case saved successfully
        400: Invalid parameters or missing fields
        401: Unauthorized (missing/invalid token)
        500: Database error
    """
    try:
        data = request.get_json() or {}

        # Validate required fields
        required_fields = [
            'patient_name', 'patient_id', 'date', 'surgery_type',
            'anesthetic_agent', 'molecular_mass', 'vapor_constant', 'density'
        ]
        
        for field in required_fields:
            if field not in data:
                return jsonify({"message": f"Missing field: {field}"}), 400

        # Extract user_id from authenticated user
        user_id = int(current_user.get('user_id'))
        
        print(f"💾 Saving case: {data['patient_name']} ({data['patient_id']}) for user {user_id}")
        new_case = Case(
            user_id=user_id,
            patient_name=data['patient_name'],
            patient_id=data['patient_id'],
            date=data['date'],
            surgery_type=data['surgery_type'],
            anesthetic_agent=data['anesthetic_agent'],
            molecular_mass=data['molecular_mass'],
            vapor_constant=data['vapor_constant'],
            density=data['density'],
            fresh_gas_flow=data.get('fresh_gas_flow'),
            dial_concentration=data.get('dial_concentration'),
            time_minutes=data.get('time_minutes'),
            initial_weight=data.get('initial_weight'),
            final_weight=data.get('final_weight'),
            notes=data.get('notes'),
            biro_formula=data.get('biro_formula'),
            dion_formula=data.get('dion_formula'),
            weight_based=data.get('weight_based'),
            induction_fgf=data.get('induction_fgf'),
            induction_concentration=data.get('induction_concentration'),
            induction_time=data.get('induction_time'),
            induction_biro=data.get('induction_biro'),
            induction_dion=data.get('induction_dion'),
            final_biro=data.get('final_biro'),
            final_dion=data.get('final_dion'),
            maintenance_rows=json_lib.dumps(data.get('maintenance_rows', [])),
            maintenance_calculations=json_lib.dumps(data.get('maintenance_calculations', [])),
        )

        db.session.add(new_case)
        db.session.commit()

        case_id = new_case.id
        print(f"✅ Case saved with ID: {case_id}")

        return jsonify({
            "success": True,
            "message": "Case saved successfully",
            "case": {
                "id": case_id,
                "patient_name": data['patient_name'],
                "patient_id": data['patient_id'],
                "date": data['date']
            }
        }), 201

    except Exception as e:
        db.session.rollback()
        print(f"❌ Error saving case: {str(e)}")
        return jsonify({"message": f"Error: {str(e)}"}), 500


@calculator_bp.route('/cases', methods=['GET'])
@require_token
def get_cases(current_user):
    """
    Fetch all saved patient cases from database for authenticated user
    
    Requires JWT authentication. Returns only cases belonging to the logged-in user.
    
    Returns:
        200: List of user's cases ordered by latest first
        401: Unauthorized (missing/invalid token)
        500: Database error
    """
    try:
        # Extract user_id from authenticated user
        user_id = int(current_user.get('user_id'))
        
        print(f"📋 Fetching cases for user {user_id}...")
        # Filter cases by user_id
        cases = Case.query.filter_by(user_id=user_id).order_by(Case.created_at.desc()).all()
        cases_data = [c.to_dict() for c in cases]

        print(f"✅ Retrieved {len(cases_data)} cases for user {user_id}")

        return jsonify({
            "success": True,
            "message": "Cases retrieved successfully",
            "cases": cases_data,
            "count": len(cases_data)
        }), 200

    except Exception as e:
        print(f"❌ Error fetching cases: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}",
            "cases": []
        }), 500


@calculator_bp.route('/stats', methods=['GET'])
@require_token
def get_home_stats(current_user):
    """
    Fetch aggregate home screen statistics for the authenticated user.
    """
    try:
        user_id = int(current_user.get('user_id'))

        start_of_day = datetime.combine(datetime.utcnow().date(), time.min)
        end_of_day = start_of_day + timedelta(days=1)

        case_count = db.session.query(func.count(Case.id)).filter(
            Case.user_id == user_id,
        ).scalar() or 0

        case_today_count = db.session.query(func.count(Case.id)).filter(
            Case.user_id == user_id,
            Case.created_at >= start_of_day,
            Case.created_at < end_of_day,
        ).scalar() or 0

        oxygen_count = db.session.query(func.count(OxygenCalculation.id)).filter(
            OxygenCalculation.user_id == user_id,
        ).scalar() or 0

        oxygen_today_count = db.session.query(func.count(OxygenCalculation.id)).filter(
            OxygenCalculation.user_id == user_id,
            OxygenCalculation.created_at >= start_of_day,
            OxygenCalculation.created_at < end_of_day,
        ).scalar() or 0

        total_calculations = case_count + oxygen_count
        todays_calculations = case_today_count + oxygen_today_count

        most_used_module = None
        if total_calculations > 0:
            if oxygen_count > case_count:
                most_used_module = {
                    "key": "oxygen",
                    "title": "Oxygen Cylinder Duration",
                    "count": oxygen_count,
                }
            else:
                most_used_module = {
                    "key": "volatile",
                    "title": "Volatile Anesthetic Consumption",
                    "count": case_count,
                }

        return jsonify({
            "success": True,
            "stats": {
                "total_calculations": total_calculations,
                "saved_records": case_count,
                "todays_calculations": todays_calculations,
                "most_used_module": most_used_module,
            },
        }), 200

    except Exception as e:
        db.session.rollback()
        print(f"❌ Error fetching home stats: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}",
            "stats": None,
        }), 500


@calculator_bp.route('/cases/<int:case_id>', methods=['GET'])
@require_token
def get_case(case_id, current_user):
    """
    Fetch a specific case by ID
    
    Requires JWT authentication. User can only access their own cases.
    
    Args:
        case_id: Case ID (path parameter)
    
    Returns:
        200: Case details
        401: Unauthorized (missing/invalid token)
        403: Forbidden (case belongs to different user)
        404: Case not found
        500: Database error
    """
    try:
        # Extract user_id from authenticated user
        user_id = int(current_user.get('user_id'))
        
        print(f"🔍 Fetching case {case_id} for user {user_id}...")
        case = Case.query.filter_by(id=case_id).first()

        if case:
            # Verify ownership
            if case.user_id != user_id:
                print(f"❌ User {user_id} attempted to access case {case_id} belonging to user {case.user_id}")
                return jsonify({
                    "success": False,
                    "message": "Unauthorized access to this case"
                }), 403
            
            print(f"✅ Case {case_id} found")
            return jsonify({
                "success": True,
                "message": "Case retrieved successfully",
                "case": case.to_dict()
            }), 200
        else:
            print(f"❌ Case {case_id} not found")
            return jsonify({
                "success": False,
                "message": "Case not found"
            }), 404

    except Exception as e:
        print(f"❌ Error fetching case: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}"
        }), 500


@calculator_bp.route('/cases/<int:case_id>', methods=['PUT', 'PATCH'])
@require_token
def update_case(case_id, current_user):
    """
    Update an existing case by ID

    Requires JWT authentication. User can only update their own cases.
    
    Expects JSON body with fields to update. Fields not provided will keep previous values.
    Returns:
        200: Case updated successfully
        401: Unauthorized (missing/invalid token)
        403: Forbidden (case belongs to different user)
        404: Case not found
        500: Database error
    """
    try:
        # Extract user_id from authenticated user
        user_id = int(current_user.get('user_id'))
        
        print(f"✏️ Update request received for case {case_id} from user {user_id} - method={request.method}")
        data = request.get_json() or {}

        existing = Case.query.filter_by(id=case_id).first()
        if not existing:
            print(f"❌ Case {case_id} not found for update")
            return jsonify({"success": False, "message": "Case not found"}), 404
        
        # Verify ownership
        if existing.user_id != user_id:
            print(f"❌ User {user_id} attempted to update case {case_id} belonging to user {existing.user_id}")
            return jsonify({"success": False, "message": "Unauthorized access to this case"}), 403

        # Update only provided fields
        field_map = {
            'patient_name': 'patient_name',
            'patient_id': 'patient_id',
            'date': 'date',
            'surgery_type': 'surgery_type',
            'anesthetic_agent': 'anesthetic_agent',
            'molecular_mass': 'molecular_mass',
            'vapor_constant': 'vapor_constant',
            'density': 'density',
            'fresh_gas_flow': 'fresh_gas_flow',
            'dial_concentration': 'dial_concentration',
            'time_minutes': 'time_minutes',
            'initial_weight': 'initial_weight',
            'final_weight': 'final_weight',
            'notes': 'notes',
            'biro_formula': 'biro_formula',
            'dion_formula': 'dion_formula',
            'weight_based': 'weight_based',
            'induction_fgf': 'induction_fgf',
            'induction_concentration': 'induction_concentration',
            'induction_time': 'induction_time',
            'induction_biro': 'induction_biro',
            'induction_dion': 'induction_dion',
            'final_biro': 'final_biro',
            'final_dion': 'final_dion',
        }

        for payload_key, model_attr in field_map.items():
            if payload_key in data:
                setattr(existing, model_attr, data[payload_key])

        if 'maintenance_rows' in data:
            existing.maintenance_rows = json_lib.dumps(data.get('maintenance_rows') or [])

        if 'maintenance_calculations' in data:
            existing.maintenance_calculations = json_lib.dumps(data.get('maintenance_calculations') or [])

        print(f"📤 Executing update for case {case_id}")
        db.session.commit()

        print(f"✅ Case {case_id} updated successfully by user {user_id}")
        return jsonify({"success": True, "message": "Case updated successfully", "case": {"id": case_id}}), 200

    except Exception as e:
        db.session.rollback()
        print(f"❌ Error updating case: {str(e)}")
        return jsonify({"success": False, "message": f"Error: {str(e)}"}), 500


@calculator_bp.route('/cases/<int:case_id>', methods=['DELETE'])
@require_token
def delete_case(case_id, current_user):
    """
    Delete a patient case
    
    Requires JWT authentication. User can only delete their own cases.
    
    Args:
        case_id: Case ID (path parameter)
    
    Returns:
        200: Case deleted successfully
        401: Unauthorized (missing/invalid token)
        403: Forbidden (case belongs to different user)
        404: Case not found
        500: Database error
    """
    try:
        # Extract user_id from authenticated user
        user_id = int(current_user.get('user_id'))
        
        print(f"🗑️  Deleting case {case_id} by user {user_id}...")
        case = Case.query.filter_by(id=case_id).first()

        if case:
            # Verify ownership
            if case.user_id != user_id:
                print(f"❌ User {user_id} attempted to delete case {case_id} belonging to user {case.user_id}")
                return jsonify({
                    "success": False,
                    "message": "Unauthorized access to this case"
                }), 403
            
            db.session.delete(case)
            db.session.commit()
            print(f"✅ Case {case_id} deleted by user {user_id}")
            return jsonify({
                "success": True,
                "message": "Case deleted successfully"
            }), 200
        else:
            print(f"❌ Case {case_id} not found")
            return jsonify({
                "success": False,
                "message": "Case not found"
            }), 404

    except Exception as e:
        db.session.rollback()
        print(f"❌ Error deleting case: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}"
        }), 500
